import json
from time import sleep
import requests
from requests.exceptions import RequestException
from lxml import etree
from urllib.parse import quote


class JobSpider(object):
    def __init__(self):
        # 将城市和职位格式化的url
        self.BASE_URL = "https://search.51job.com/list/{},000000,0000,00,9,99,{},2,1.html?lang=c&stype=&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&providesalary=99&lonlat=0%2C0&radius=-1&ord_field=0&confirmdate=9&fromType=&dibiaoid=0&address=&line=&specialarea=00&from=&welfare="
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36"
        }
        # 设置一个城市名称，便于写入文件
        self.area = None

    # 将格式化后的url返回
    def url_manager(self):
        # 读取area.json文件
        with open("area.json", "r", encoding="utf8") as file:
            # 将城市信息id转换为字典
            area_data = json.load(file)
            file.close()
        # 职位名称需要编码两次
        position = "大数据"
        area_list = ["北京", "上海", "广州", "深圳", "成都"]
        for area in area_list:
            self.area = area
            print(self.area)
            encode_position = quote(quote(position))
            # 取出对应的城市的id
            area_id = area_data[area]
            # 将url进行格式化
            url = self.BASE_URL.format(area_id, encode_position)
            # 封装成一个生成器
            yield url

    # 爬取方法，只要爬取到html就将html交给解析函数
    def crawler(self, url):
        try:
            response = requests.get(url=url, headers=self.headers)
            if response.status_code == 200:
                html = response.content.decode("gbk")
                self.parser(html)
            return None
        except RequestException:
            return None

    # 解析html
    def parser(self, html):
        # 定义一个空列表用于存放一页的数据
        items = []
        # 使用xpath解析，初始化element对象
        element = etree.HTML(html)
        # 提取所有职位信息的div标签
        el_list = element.xpath("//div[@id='resultList']/div[@class='el']")
        # 提取下一页的url，如果是最后一页则不能提取到
        next_page_url = element.xpath("//div[@class='p_in']/ul/li[last()]/a/@href")
        # 遍历提取到的职位信息
        for el in el_list:
            try:
                # 在当前结点下提取职位信息，并取出职位名称，如果提取不到则取第0个元素会报错，取不到就设置位None
                position = el.xpath("./p/span/a/@title")[0]
            except Exception:
                position = None
            try:
                company = el.xpath("./span[1]/a/@title")[0]
            except Exception:
                company = None
            try:
                address = el.xpath("./span[2]/text()")[0]
            except Exception:
                address = None
            try:
                salary = el.xpath("./span[3]/text()")[0]
            except Exception:
                salary = None
            try:
                datetime = el.xpath("./span[4]/text()")[0]
            except Exception:
                datetime = None
            # 将提取到的数据放入字典中，然后添加到item中
            message = {
                "position": position,
                "company": company,
                "address": address,
                "salary": salary,
                "datetime": datetime
            }
            items.append(message)
        # 如果item不为空则写入数据
        if items:
            self.write_to_csv(items)
        # 如果这一页不是尾页，则将下一页的链接交给crawler方法爬取html
        if next_page_url:
            self.crawler(next_page_url[0])

    # 将文件写入csv
    def write_to_csv(self, items):
        # 定义文件名
        fp = self.area + "JobData.csv"
        with open(fp, mode="a", encoding="gbk") as file:
            for item in items:
                data = f"{item['position']},{item['company']},{item['address']},{item['salary']},{item['datetime']}\n"
                file.write(data)
            file.close()
            sleep(2)

    # 调度所有方法
    def run(self):
        url_gen = self.url_manager()
        for url in url_gen:
            self.crawler(url)


if __name__ == '__main__':
    spider = JobSpider()
    spider.run()
