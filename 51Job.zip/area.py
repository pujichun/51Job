import json
import ast
import requests
from requests.exceptions import RequestException
import re


class AreaSpider(object):
    def __init__(self):
        # common.6ce831ef.js文件的请求url
        self.url = "https://js.51jobcdn.com/in/resource/js/2020/search/common.6ce831ef.js"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36"
        }

    def crawler(self):
        try:
            response = requests.get(url=self.url, headers=self.headers)
            if response.status_code == 200:
                return response.content.decode("gbk")
            return None
        except RequestException:
            return None

    # 解析返回的Javascript文件，提取出地区信息
    @staticmethod
    def parser(data):
        # 加一个模式修正符re.S，让\s能匹配空格
        area = re.findall('"use\sstrict";window\.area=(\{.*?\})', data, re.S)[0]
        # 因为地区信息中的数据并不是规范的json格式，所以不能使用json.loads()方法，这里使用ast模块下的literal_eval方法
        area_json = ast.literal_eval(area)
        area_json = {value: key for key, value in area_json.items()}
        return area_json

    # 将地区信息写入json文件中
    @staticmethod
    def write_to_json(data):
        with open("area.json", "w", encoding="utf-8") as file:
            # indent=4让json文件有缩进，ensure_ascii=False防止中文乱码
            json_data = json.dumps(data, indent=4, ensure_ascii=False)
            file.write(json_data)
            file.close()

    def run(self):
        data = self.crawler()
        area_json = self.parser(data)
        self.write_to_json(area_json)


if __name__ == '__main__':
    spider = AreaSpider()
    spider.run()
